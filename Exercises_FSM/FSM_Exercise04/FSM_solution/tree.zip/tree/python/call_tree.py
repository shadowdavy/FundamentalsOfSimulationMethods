from tree import *
import time
from copy import *
import numpy as np



def computeWithTree(particles, openingAngle):
    q = TreeClass(particles)
    q.insertallparticles()
    q.computemultipoles(0)


    print("Starting tree gravity with ", str(len(particles)), " particles and theta = ", str(openingAngle))
    t0 = time.time()
    q.allgforces(openingAngle)
    t1 = time.time()
    dt = t1 - t0
    fapprox = -deepcopy(q.forces)
    return fapprox, q, dt

def computeWithDirectSummationNumpy(particles):
    print("starting N^2 gravity with ", str(len(particles)), " particles")
    t0 = time.time()

    eps = 1e-3
    diff = particles[:,np.newaxis] - particles
    r2 = np.repeat(np.sum(diff**2, axis=2)[:, :, np.newaxis], 3, axis=2)
    r2 = np.where(r2==0.0, np.inf, r2)
    r2 += eps**2
    r3 = r2**1.5
    r3_inv = 1.0 / r3
    forces = -np.sum(diff*r3_inv, axis=1)

    t1 = time.time()
    dt = t1 - t0
    return forces, dt

def computeWithDirectSummation(particles):
    print("starting N^2 gravity")
    t0 = time.time()

    eps = 1e-3
    forces = []
    for i in range(len(particles)):
        force = np.zeros(3, dtype=np.float64)
        for j in range(len(particles)):
            if i != j:
                dx = particles[j] - particles[i]
                dr2 = np.sum(dx**2) + eps**2
                force += dx / dr2**1.5
        forces.append(force)


    t1 = time.time()
    fullgrav_dt = t1 - t0
    print("done in " + str(fullgrav_dt) + " seconds\n")

    return np.array(forces)

def compareForces(fapprox, fexact):
    pass

